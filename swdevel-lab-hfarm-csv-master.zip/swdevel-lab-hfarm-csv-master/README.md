# Lab of Software Project Development - Week 4

This repository contains the source code for the Week 4 laboratory activity of the "Lab of Software Project Development" course at Ca' Foscari University of Venice.

## Instructions

Please refer to the instructions provided on the Moodle page of the course for detailed information on the laboratory activity. The instructions will guide you through the exploration of Pandas for data handling, using the provided Python scripts (`main_csv.py` and `main_pandas.py`), and leveraging tools such as Visual Studio Code and Docker for an interactive learning experience.
